//sidebars	
var lable = document.getElementById("lable");		
var sidebars = document.getElementById("sidebars");		
lable.onmouseover = function(){		
	animate(sidebars, "left", 0);		
	sidebars.onmouseover = function(){		
		animate(sidebars,"left",0);			
		sidebars.onmouseout = function(){			
		animate(sidebars,"left",-200);			
		}		
	}		
}		
lable.onmouseout = function(){
	animate(sidebars, "left", -200);
}
// animate运动函数
function animate(tag, attr, target) {
    clearInterval(tag.timer);//计时
    tag.timer = setInterval(function () {

        // 获取某个属性的当前状态
        // 由于具有单位，需要取整
        // parseInt("hehe") => NaN    NaN || 0
        // 为了应对auto转换为NaN的问题，我们使用短路操作，保证程序的健壮性
        var leader = parseInt(getStyle(tag, attr)) || 0;

        // 缓动公式的一部分是更改step的值
        var step = (target - leader) / 5;//speed

        // 由offsetLeft在取值的时候会四舍五入，step如果比较小，会造成无法运动的问题
        // 根据步数的正负，更改取整方式
        step = step > 0 ? Math.ceil(step) : Math.floor(step);

        // 缓动公式
        leader = leader + step;

        // 设置给某一个属性
        tag.style[attr] = leader + "px";

        // 检测是否走到了指定位置
        if (leader == target) {
            clearInterval(tag.timer);
        }
    }, 17);
}

// 用于获取某个标签的某个样式属性值
// 带单位
function getStyle(tag, attr) {
    // 检测支持哪一个
    // box.currentStyle，如果不存在值为undefined
    // getComputedStyle如果浏览器不支持。相当于变量未声明，报错
    if (tag.currentStyle) {
        // ie支持
        return tag.currentStyle[attr];
    } else {
        // 标准方法
        return getComputedStyle(tag, null)[attr];
    }
}		lable.onmouseout = function(){
	animate(sidebars, "left", -200);
}
// animate运动函数
function animate(tag, attr, target) {
    clearInterval(tag.timer);//计时
    tag.timer = setInterval(function () {

        // 获取某个属性的当前状态
        // 由于具有单位，需要取整
        // parseInt("hehe") => NaN    NaN || 0
        // 为了应对auto转换为NaN的问题，我们使用短路操作，保证程序的健壮性
        var leader = parseInt(getStyle(tag, attr)) || 0;

        // 缓动公式的一部分是更改step的值
        var step = (target - leader) / 5;//speed

        // 由offsetLeft在取值的时候会四舍五入，step如果比较小，会造成无法运动的问题
        // 根据步数的正负，更改取整方式
        step = step > 0 ? Math.ceil(step) : Math.floor(step);

        // 缓动公式
        leader = leader + step;

        // 设置给某一个属性
        tag.style[attr] = leader + "px";

        // 检测是否走到了指定位置
        if (leader == target) {
            clearInterval(tag.timer);
        }
    }, 17);
}

// 用于获取某个标签的某个样式属性值
// 带单位
function getStyle(tag, attr) {
    // 检测支持哪一个
    // box.currentStyle，如果不存在值为undefined
    // getComputedStyle如果浏览器不支持。相当于变量未声明，报错
    if (tag.currentStyle) {
        // ie支持
        return tag.currentStyle[attr];
    } else {
        // 标准方法
        return getComputedStyle(tag, null)[attr];
    }
}	
		
//changeimg
var index2 = 0;/*初始化一个变量 指向下彪*/
//点击点
$(".tab-btn .btn").click(function () {
    index2 = $(this).index();//获取点击该元素下彪
    $(this).addClass("active").siblings().removeClass("active");
    $(".item").eq(index2).fadeIn().siblings().fadeOut();
});

//点击切换效果
$(".lr-tab .right").click(function () {
    index2 ++;
    if (index2 >4){ index2 = 0;}
    $(".item").eq(index2).fadeIn().siblings().fadeOut();
    $(".tab-btn .btn").eq(index2).addClass("active").siblings().removeClass("active");
});

$(".lr-tab .left").click(function () {
    index2 --;
    if(index2 < 0){index2 = 4;}
    $(".item").eq(index2).fadeIn().siblings().fadeOut();
    $(".tab-btn .btn").eq(index2).addClass("active").siblings().removeClass("active");
});

var time2 = setInterval(function () {
    index2 ++;
    if (index2 >4){ index2 = 0;}
    $(".item").eq(index2).fadeIn().siblings().fadeOut();
    $(".tab-btn .btn").eq(index2).addClass("active").siblings().removeClass("active");

},4000); //定时器 重复
